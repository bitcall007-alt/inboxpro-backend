import { useState } from "react";

// ============================================================
// 🔑 PON AQUÍ TU API KEY DE ANTHROPIC
// Consíguela en: https://console.anthropic.com → API Keys
// ============================================================
const ANTHROPIC_API_KEY = "sk-ant-PON-TU-CLAVE-AQUI";

const STYLES = `
  @import url('https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@400;600;800&display=swap');

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --bg: #080c12;
    --surface: #0e1420;
    --surface2: #151c2c;
    --border: #1e2d47;
    --accent: #00e5ff;
    --accent2: #7c3aed;
    --green: #00ff9d;
    --red: #ff3860;
    --yellow: #ffd600;
    --text: #e2e8f0;
    --muted: #64748b;
    --font-display: 'Syne', sans-serif;
    --font-mono: 'Space Mono', monospace;
  }

  body { background: var(--bg); color: var(--text); font-family: var(--font-display); min-height: 100vh; }

  .app { display: flex; min-height: 100vh; }

  .sidebar {
    width: 220px; min-height: 100vh; background: var(--surface);
    border-right: 1px solid var(--border); display: flex; flex-direction: column;
    padding: 24px 0; position: fixed; top: 0; left: 0; z-index: 100;
  }
  .logo {
    padding: 0 20px 28px; border-bottom: 1px solid var(--border);
    font-family: var(--font-display); font-weight: 800; font-size: 18px;
    letter-spacing: -0.5px; line-height: 1.2;
  }
  .logo span { color: var(--accent); }
  .logo small { display: block; font-size: 10px; color: var(--muted); font-weight: 400; letter-spacing: 2px; text-transform: uppercase; margin-top: 2px; }
  .nav { padding: 16px 0; flex: 1; }
  .nav-item {
    display: flex; align-items: center; gap: 10px; padding: 10px 20px;
    cursor: pointer; font-size: 13px; font-weight: 600; color: var(--muted);
    transition: all 0.2s; border-left: 3px solid transparent; letter-spacing: 0.3px;
  }
  .nav-item:hover { color: var(--text); background: var(--surface2); }
  .nav-item.active { color: var(--accent); border-left-color: var(--accent); background: rgba(0,229,255,0.05); }
  .nav-item .icon { font-size: 16px; }
  .sidebar-badge {
    margin-left: auto; background: var(--accent2); color: white;
    font-size: 10px; padding: 2px 6px; border-radius: 20px; font-family: var(--font-mono);
  }
  .sidebar-footer { padding: 0 20px 20px; border-top: 1px solid var(--border); padding-top: 16px; }
  .sidebar-footer .day-label { font-size: 11px; color: var(--muted); margin-bottom: 6px; }
  .sidebar-footer .day-value { font-family: var(--font-mono); font-size: 20px; font-weight: 700; color: var(--accent); }
  .sidebar-footer .day-sub { font-size: 11px; color: var(--muted); }

  .main { margin-left: 220px; flex: 1; padding: 32px; }
  .page-header { margin-bottom: 28px; }
  .page-header h1 { font-size: 26px; font-weight: 800; letter-spacing: -0.5px; }
  .page-header p { color: var(--muted); font-size: 13px; margin-top: 4px; }
  .page-header-row { display: flex; justify-content: space-between; align-items: flex-start; }

  .card { background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: 20px; }
  .card-title { font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 1.5px; color: var(--muted); margin-bottom: 14px; }
  .grid-4 { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 24px; }
  .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 24px; }
  .grid-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px; margin-bottom: 24px; }
  .mb-4 { margin-bottom: 16px; }

  .stat-card { background: var(--surface); border: 1px solid var(--border); border-radius: 12px; padding: 20px; position: relative; overflow: hidden; }
  .stat-card::after { content: ''; position: absolute; bottom: 0; left: 0; right: 0; height: 2px; }
  .stat-card.cyan::after { background: var(--accent); }
  .stat-card.purple::after { background: var(--accent2); }
  .stat-card.green::after { background: var(--green); }
  .stat-card.yellow::after { background: var(--yellow); }
  .stat-label { font-size: 11px; color: var(--muted); text-transform: uppercase; letter-spacing: 1px; font-weight: 700; }
  .stat-value { font-size: 30px; font-weight: 800; margin: 6px 0 4px; letter-spacing: -1px; font-family: var(--font-mono); }
  .stat-value.cyan { color: var(--accent); }
  .stat-value.purple { color: var(--accent2); }
  .stat-value.green { color: var(--green); }
  .stat-value.yellow { color: var(--yellow); }
  .stat-sub { font-size: 11px; color: var(--muted); }

  .bar-track { background: var(--surface2); border-radius: 4px; height: 8px; overflow: hidden; }
  .bar-fill { height: 100%; border-radius: 4px; background: linear-gradient(90deg, var(--accent2), var(--accent)); transition: width 0.6s ease; }
  .warming-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
  .warming-title { font-size: 13px; font-weight: 700; }
  .warming-info { font-size: 12px; color: var(--accent); font-family: var(--font-mono); }
  .day-steps { display: flex; gap: 6px; margin-top: 10px; flex-wrap: wrap; }
  .day-pill {
    font-size: 10px; font-family: var(--font-mono); padding: 3px 8px; border-radius: 20px;
    background: var(--surface2); color: var(--muted); border: 1px solid var(--border);
    cursor: pointer; transition: all 0.15s;
  }
  .day-pill.active { background: var(--accent); color: var(--bg); border-color: var(--accent); font-weight: 700; }
  .day-pill.done { border-color: var(--green); color: var(--green); }

  .chart-wrap { height: 160px; display: flex; align-items: flex-end; gap: 4px; padding-top: 10px; }
  .chart-bar-wrap { flex: 1; display: flex; flex-direction: column; align-items: center; gap: 4px; height: 100%; justify-content: flex-end; }
  .chart-bar { width: 100%; border-radius: 4px 4px 0 0; transition: height 0.6s ease; min-height: 4px; cursor: pointer; }
  .chart-label { font-size: 9px; color: var(--muted); font-family: var(--font-mono); }

  .status-grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 12px; }
  .status-item { display: flex; align-items: center; gap: 8px; background: var(--surface2); border-radius: 8px; padding: 10px 14px; }
  .status-name { font-size: 13px; font-weight: 600; }
  .status-val { margin-left: auto; font-size: 11px; }

  .btn {
    display: inline-flex; align-items: center; gap: 8px; padding: 10px 20px;
    border-radius: 8px; font-family: var(--font-display); font-weight: 700; font-size: 13px;
    cursor: pointer; border: none; transition: all 0.2s; letter-spacing: 0.3px;
  }
  .btn-primary { background: var(--accent); color: var(--bg); }
  .btn-primary:hover { background: #00c8e0; transform: translateY(-1px); }
  .btn-primary:disabled { opacity: 0.5; cursor: not-allowed; transform: none; }
  .btn-outline { background: transparent; color: var(--text); border: 1px solid var(--border); }
  .btn-outline:hover { border-color: var(--accent); color: var(--accent); }
  .btn-danger { background: var(--red); color: white; }
  .btn-ghost { background: var(--surface2); color: var(--text); }
  .btn-sm { padding: 6px 12px; font-size: 11px; }
  .btn-green { background: var(--green); color: var(--bg); }
  .btn-row { display: flex; gap: 8px; margin-top: 12px; }

  .input-group { margin-bottom: 16px; }
  .input-group label { display: block; font-size: 11px; font-weight: 700; color: var(--muted); text-transform: uppercase; letter-spacing: 1px; margin-bottom: 6px; }
  .input, .textarea, .select {
    width: 100%; background: var(--surface2); border: 1px solid var(--border);
    color: var(--text); border-radius: 8px; padding: 10px 14px;
    font-family: var(--font-display); font-size: 13px; outline: none; transition: border-color 0.2s;
  }
  .input:focus, .textarea:focus, .select:focus { border-color: var(--accent); }
  .textarea { resize: vertical; min-height: 100px; line-height: 1.6; }
  .select option { background: var(--surface); }

  .ai-result {
    background: var(--surface2); border: 1px solid var(--border); border-radius: 8px;
    padding: 16px; font-size: 13px; line-height: 1.8; white-space: pre-wrap;
    min-height: 120px;
  }
  .ai-result.loading { color: var(--muted); animation: pulse 1.5s infinite; }
  @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.4} }
  .ai-cursor { display: inline-block; width: 2px; height: 14px; background: var(--accent); margin-left: 2px; animation: blink 0.8s infinite; vertical-align: middle; }
  @keyframes blink { 0%,100%{opacity:1} 50%{opacity:0} }

  .subject-box { background: var(--surface2); border-radius: 6px; padding: 8px 12px; font-size: 13px; font-weight: 700; color: var(--accent); margin-bottom: 12px; }
  .subject-label { font-size: 11px; color: var(--muted); font-weight: 700; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 4px; }

  .spam-tag {
    display: inline-flex; align-items: center; gap: 4px; padding: 3px 10px;
    border-radius: 20px; font-size: 11px; font-weight: 700; font-family: var(--font-mono); margin: 3px;
  }
  .spam-tag.bad { background: rgba(255,56,96,0.15); color: var(--red); border: 1px solid rgba(255,56,96,0.3); }
  .spam-tag.ok { background: rgba(0,255,157,0.1); color: var(--green); border: 1px solid rgba(0,255,157,0.25); }

  .ai-tips-box { margin-top: 16px; background: rgba(0,229,255,0.05); border: 1px solid rgba(0,229,255,0.15); border-radius: 8px; padding: 14px; }
  .ai-tips-title { font-size: 11px; font-weight: 700; color: var(--accent); text-transform: uppercase; letter-spacing: 1px; margin-bottom: 8px; }
  .ai-tips-body { font-size: 12px; color: var(--text); line-height: 1.7; white-space: pre-wrap; }

  table { width: 100%; border-collapse: collapse; font-size: 13px; }
  th { text-align: left; padding: 10px 14px; font-size: 10px; text-transform: uppercase; letter-spacing: 1px; color: var(--muted); font-weight: 700; border-bottom: 1px solid var(--border); }
  td { padding: 11px 14px; border-bottom: 1px solid rgba(30,45,71,0.5); }
  tr:last-child td { border-bottom: none; }
  tr:hover td { background: rgba(255,255,255,0.02); }
  .badge { display: inline-block; padding: 2px 8px; border-radius: 20px; font-size: 10px; font-weight: 700; font-family: var(--font-mono); }
  .badge-green { background: rgba(0,255,157,0.1); color: var(--green); }
  .badge-yellow { background: rgba(255,214,0,0.1); color: var(--yellow); }
  .badge-red { background: rgba(255,56,96,0.1); color: var(--red); }
  .badge-muted { background: var(--surface2); color: var(--muted); }
  .table-search { display: flex; gap: 8px; margin-bottom: 12px; align-items: center; }
  .empty-row { text-align: center; padding: 30px; color: var(--muted); }

  .tip-card { background: rgba(0,229,255,0.04); border: 1px solid rgba(0,229,255,0.15); border-radius: 10px; padding: 14px 16px; margin-bottom: 12px; }
  .tip-header { display: flex; align-items: center; gap: 8px; margin-bottom: 6px; }
  .tip-badge { font-size: 10px; font-weight: 700; padding: 2px 8px; border-radius: 20px; font-family: var(--font-mono); background: var(--accent); color: var(--bg); }
  .tip-title { font-size: 13px; font-weight: 700; }
  .tip-body { font-size: 12px; color: var(--muted); line-height: 1.6; }

  .dns-row { display: flex; gap: 12px; align-items: flex-start; margin-bottom: 10px; background: var(--surface2); border-radius: 8px; padding: 10px 14px; }
  .dns-type { font-family: var(--font-mono); font-size: 11px; font-weight: 700; color: var(--accent); min-width: 50px; }
  .dns-record { font-family: var(--font-mono); font-size: 11px; color: var(--muted); }

  .toggle-wrap { display: flex; align-items: center; gap: 10px; margin-bottom: 10px; }
  .toggle { position: relative; width: 38px; height: 20px; cursor: pointer; }
  .toggle input { opacity: 0; width: 0; height: 0; }
  .toggle-slider { position: absolute; inset: 0; background: var(--surface2); border-radius: 20px; transition: 0.2s; border: 1px solid var(--border); }
  .toggle-slider::before { content: ''; position: absolute; height: 14px; width: 14px; left: 2px; top: 2px; background: var(--muted); border-radius: 50%; transition: 0.2s; }
  .toggle input:checked + .toggle-slider { background: var(--accent); border-color: var(--accent); }
  .toggle input:checked + .toggle-slider::before { transform: translateX(18px); background: var(--bg); }
  .toggle-label { font-size: 13px; font-weight: 600; }

  /* EXCEL IMPORTER */
  .drop-zone {
    border: 2px dashed var(--border); border-radius: 14px; padding: 48px 24px;
    text-align: center; cursor: pointer; transition: all 0.2s; background: var(--surface2);
    position: relative;
  }
  .drop-zone:hover, .drop-zone.drag-over { border-color: var(--accent); background: rgba(0,229,255,0.04); }
  .drop-zone input[type=file] { position: absolute; inset: 0; opacity: 0; cursor: pointer; width: 100%; height: 100%; }
  .drop-icon { font-size: 40px; margin-bottom: 12px; }
  .drop-title { font-size: 16px; font-weight: 800; margin-bottom: 6px; }
  .drop-sub { font-size: 12px; color: var(--muted); }
  .drop-formats { display: flex; gap: 8px; justify-content: center; margin-top: 12px; }
  .format-tag { font-size: 10px; font-family: var(--font-mono); font-weight: 700; padding: 3px 10px; border-radius: 20px; border: 1px solid var(--border); color: var(--muted); }
  .format-tag.xl { border-color: #1d6f42; color: #1d6f42; background: rgba(29,111,66,0.1); }
  .format-tag.csv { border-color: var(--accent); color: var(--accent); background: rgba(0,229,255,0.08); }

  .col-mapper { background: var(--surface2); border-radius: 10px; padding: 16px; margin-bottom: 16px; }
  .col-mapper-title { font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; color: var(--muted); margin-bottom: 12px; }
  .col-row { display: flex; align-items: center; gap: 12px; margin-bottom: 10px; }
  .col-field { font-size: 12px; font-weight: 700; min-width: 100px; }
  .col-field .required { color: var(--red); margin-left: 2px; }
  .col-arrow { color: var(--muted); font-size: 14px; }

  .import-stats { display: grid; grid-template-columns: repeat(4,1fr); gap: 12px; margin-bottom: 20px; }
  .import-stat { background: var(--surface2); border-radius: 8px; padding: 14px; text-align: center; }
  .import-stat-val { font-size: 22px; font-weight: 800; font-family: var(--font-mono); }
  .import-stat-label { font-size: 10px; color: var(--muted); text-transform: uppercase; letter-spacing: 1px; margin-top: 2px; }

  .preview-wrap { overflow-x: auto; }
  .import-progress { height: 4px; background: var(--surface2); border-radius: 2px; margin: 12px 0; overflow: hidden; }
  .import-progress-bar { height: 100%; background: linear-gradient(90deg, var(--accent2), var(--accent)); transition: width 0.3s; }

  .step-indicator { display: flex; align-items: center; gap: 0; margin-bottom: 28px; }
  .step { display: flex; align-items: center; gap: 8px; }
  .step-num { width: 28px; height: 28px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: 800; font-family: var(--font-mono); border: 2px solid var(--border); color: var(--muted); background: var(--surface2); }
  .step.active .step-num { border-color: var(--accent); color: var(--accent); background: rgba(0,229,255,0.1); }
  .step.done .step-num { border-color: var(--green); color: var(--bg); background: var(--green); }
  .step-label { font-size: 12px; font-weight: 600; color: var(--muted); }
  .step.active .step-label { color: var(--text); }
  .step.done .step-label { color: var(--green); }
  .step-line { flex: 1; height: 1px; background: var(--border); margin: 0 8px; min-width: 24px; }
  .step-line.done { background: var(--green); }

  .status-dot { width: 7px; height: 7px; border-radius: 50%; display: inline-block; margin-right: 5px; }
  .dot-green { background: var(--green); box-shadow: 0 0 6px var(--green); animation: dotpulse 2s infinite; }
  .dot-yellow { background: var(--yellow); }
  .dot-red { background: var(--red); }
  @keyframes dotpulse { 0%,100%{opacity:1} 50%{opacity:0.4} }

  ::-webkit-scrollbar { width: 4px; }
  ::-webkit-scrollbar-track { background: var(--bg); }
  ::-webkit-scrollbar-thumb { background: var(--border); border-radius: 2px; }
`;

// ─── CONSTANTS ───────────────────────────────────────────────
const CONTACTS_INIT = [
  { id:1, name:"Ana García",    email:"ana@empresa.com",    segment:"Hot",  opens:12, clicks:4, status:"Activo" },
  { id:2, name:"Carlos Ruiz",   email:"carlos@startup.io",  segment:"Warm", opens:5,  clicks:1, status:"Activo" },
  { id:3, name:"María López",   email:"maria@corp.es",      segment:"Cold", opens:0,  clicks:0, status:"Sin abrir" },
  { id:4, name:"Javier Torres", email:"javier@mipyme.com",  segment:"Hot",  opens:20, clicks:9, status:"Activo" },
  { id:5, name:"Laura Sánchez", email:"laura@negocio.net",  segment:"Warm", opens:3,  clicks:0, status:"Baja" },
  { id:6, name:"Pedro Martín",  email:"pedro@freelance.es", segment:"Cold", opens:1,  clicks:0, status:"Sin abrir" },
];

const WARMUP_DAYS = Array.from({length:20}, (_,i) => ({ day:i+1, limit:50+i*25 }));

const FORBIDDEN = ["gratis","gana dinero","100%","urgente","clic aquí","oferta","promoción","gana ahora","sin riesgo","exclusivo"];

const ANTI_SPAM_TIPS = [
  { cat:"Dominio",   title:"SPF + DKIM + DMARC configurados",       body:"El 89% de los emails que evitan spam tienen los tres registros DNS. Verifica en mxtoolbox.com antes de enviar." },
  { cat:"Warming",   title:"Incremento gradual de volumen",          body:"Empieza en 50/día y sube 25 cada día. Los ESPs detectan aumentos bruscos como señal de spam." },
  { cat:"Contenido", title:"Ratio texto/imagen >60%",                body:"Los filtros modernos penalizan emails con mucha imagen y poco texto. Escribe como un humano real." },
  { cat:"Técnica",   title:"Plain-text alternativo siempre",         body:"Incluye siempre una versión plain-text. Los filtros de Gmail/Outlook lo valoran positivamente." },
  { cat:"Headers",   title:"Message-ID y Reply-To personalizados",   body:"Usa Message-ID únicos por envío y un Reply-To real. Evita headers genéricos de mass-mailer." },
  { cat:"Timing",    title:"Envía en horario humano",                 body:"09:00–11:00 y 14:00–16:00 hora local del destinatario. Evita medianoche y fines de semana." },
  { cat:"Lista",     title:"Limpieza de lista cada 30 días",         body:"Elimina hard bounces inmediatamente y soft bounces tras 3 intentos. Una lista limpia mejora el sender score." },
  { cat:"Variación", title:"Spintax en asunto y cuerpo",             body:"Varía ligeramente cada email: nombre, frase de apertura, CTA. Rompe patrones de fingerprinting." },
];

// ─── HELPERS ─────────────────────────────────────────────────
function calcSpamScore(text) {
  if (!text) return 100;
  let score = 100;
  const lower = text.toLowerCase();
  FORBIDDEN.forEach(w => { if (lower.includes(w)) score -= 15; });
  if ((text.match(/!/g)||[]).length > 2) score -= 10;
  if ((text.match(/\$/g)||[]).length > 0) score -= 8;
  if (text === text.toUpperCase() && text.length > 10) score -= 20;
  return Math.max(0, Math.min(100, score));
}

async function callClaude(prompt, maxTokens = 800) {
  const resp = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true",
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: maxTokens,
      messages: [{ role: "user", content: prompt }],
    }),
  });
  const data = await resp.json();
  return data.content?.map(b => b.text || "").join("") || "";
}

// ─── COMPONENTS ──────────────────────────────────────────────
function SpamScoreRing({ score }) {
  const r = 36, c = 2 * Math.PI * r;
  const fill = (score / 100) * c;
  const color = score > 70 ? "#00ff9d" : score > 40 ? "#ffd600" : "#ff3860";
  return (
    <div style={{display:"flex",alignItems:"center",gap:16,padding:"12px 0"}}>
      <svg width={90} height={90} viewBox="0 0 90 90">
        <circle cx={45} cy={45} r={r} fill="none" stroke="#1e2d47" strokeWidth={7}/>
        <circle cx={45} cy={45} r={r} fill="none" stroke={color} strokeWidth={7}
          strokeDasharray={`${fill} ${c}`} strokeLinecap="round"
          transform="rotate(-90 45 45)" style={{transition:"stroke-dasharray 0.5s ease"}}/>
        <text x={45} y={50} textAnchor="middle" fill={color} fontSize={18} fontWeight={800} fontFamily="Space Mono">{score}</text>
      </svg>
      <div>
        <div style={{fontSize:13,fontWeight:700,color}}>
          {score>70?"✅ Buena entregabilidad":score>40?"⚠️ Riesgo medio":"🚨 Alto riesgo spam"}
        </div>
        <div style={{fontSize:11,color:"#64748b",marginTop:4}}>Puntuación anti-spam en tiempo real</div>
      </div>
    </div>
  );
}

// ─── PAGES ───────────────────────────────────────────────────

function Dashboard({ day, setDay }) {
  const limit = 50 + (day - 1) * 25;
  const progress = Math.min(100, (limit / 1000) * 100);

  return (
    <div>
      <div className="page-header">
        <h1>Panel Principal</h1>
        <p>Vista general de tu campaña de email</p>
      </div>

      <div className="grid-4">
        {[
          { label:"Enviados hoy",  value:limit,   color:"cyan"   },
          { label:"Tasa apertura", value:"34.2%", color:"green"  },
          { label:"Clics",         value:"8.7%",  color:"purple" },
          { label:"Sender Score",  value:"91",    color:"yellow" },
        ].map(s => (
          <div key={s.label} className={`stat-card ${s.color}`}>
            <div className="stat-label">{s.label}</div>
            <div className={`stat-value ${s.color}`}>{s.value}</div>
            <div className="stat-sub"><span className="status-dot dot-green"></span>En vivo</div>
          </div>
        ))}
      </div>

      <div className="grid-2">
        <div className="card">
          <div className="card-title">🔥 Warming — Día {day} / 20</div>
          <div className="warming-header">
            <span className="warming-title">Límite hoy</span>
            <span className="warming-info">{limit} / 1000 emails</span>
          </div>
          <div className="bar-track"><div className="bar-fill" style={{width:`${progress}%`}}></div></div>
          <div className="day-steps">
            {WARMUP_DAYS.map(d => (
              <div key={d.day}
                className={`day-pill ${d.day===day?"active":d.day<day?"done":""}`}
                onClick={() => setDay(d.day)}>
                D{d.day}
              </div>
            ))}
          </div>
          <div style={{fontSize:12,color:"var(--muted)",marginTop:10}}>+25 emails por día • Auto-incremento activado</div>
        </div>

        <div className="card">
          <div className="card-title">📈 Volumen de envíos</div>
          <div className="chart-wrap">
            {WARMUP_DAYS.slice(0, Math.min(day + 3, 20)).map(d => (
              <div key={d.day} className="chart-bar-wrap">
                <div className="chart-bar" style={{
                  height: `${(d.limit / 1000) * 140}px`,
                  background: d.day < day ? "#7c3aed" : d.day === day ? "#00e5ff" : "#1e2d47",
                  opacity: d.day > day ? 0.4 : 1,
                }}/>
                <div className="chart-label">D{d.day}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-title">🌐 Estado del Sistema</div>
        <div className="status-grid">
          {[
            {label:"DKIM",       status:"ok"},
            {label:"SPF",        status:"ok"},
            {label:"DMARC",      status:"ok"},
            {label:"Dominio",    status:"ok"},
            {label:"Resend API", status:"ok"},
            {label:"Lista limpia",status:"warn"},
          ].map(s => (
            <div key={s.label} className="status-item">
              <span className={`status-dot ${s.status==="ok"?"dot-green":"dot-yellow"}`}></span>
              <span className="status-name">{s.label}</span>
              <span className="status-val" style={{color:s.status==="ok"?"var(--green)":"var(--yellow)"}}>
                {s.status==="ok"?"OK":"Revisar"}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function AICompose() {
  const [name,    setName]    = useState("Ana");
  const [segment, setSegment] = useState("Hot");
  const [context, setContext] = useState("Software de gestión para pequeñas empresas");
  const [tone,    setTone]    = useState("Profesional pero cercano");
  const [subject, setSubject] = useState("");
  const [result,  setResult]  = useState("");
  const [loading, setLoading] = useState(false);
  const [streaming,setStreaming]=useState(false);
  const [score,   setScore]   = useState(null);

  const generate = async () => {
    setLoading(true); setResult(""); setSubject(""); setScore(null); setStreaming(false);
    try {
      const prompt = `Eres un experto en cold email marketing. Redacta un email de ventas en español para ${name}, segmento: ${segment}.
Producto/servicio: ${context}
Tono: ${tone}
REGLAS:
- Máx 150 palabras en el cuerpo
- NO empieces con "espero que estés bien"
- Sin palabras spam: gratis, oferta, urgente, 100%, clic aquí
- Suena humano, no corporativo
- Incluye 1 CTA claro
- Usa técnica AIDA o PAS

Responde SOLO con JSON sin markdown: {"subject":"...","body":"..."}`;

      const raw = await callClaude(prompt);
      try {
        const parsed = JSON.parse(raw.replace(/```json|```/g, "").trim());
        setSubject(parsed.subject || "");
        const body = parsed.body || "";
        setStreaming(true);
        let i = 0;
        const interval = setInterval(() => {
          i += 3;
          setResult(body.slice(0, i));
          if (i >= body.length) {
            clearInterval(interval);
            setStreaming(false);
            setScore(calcSpamScore(body));
          }
        }, 20);
      } catch {
        setResult(raw);
        setScore(calcSpamScore(raw));
      }
    } catch {
      setResult("❌ Error al conectar. Revisa tu API Key en App.jsx");
    }
    setLoading(false);
  };

  return (
    <div>
      <div className="page-header">
        <h1>Redacción con IA</h1>
        <p>Genera emails que parecen escritos por humanos, optimizados anti-spam</p>
      </div>
      <div className="grid-2">
        <div className="card">
          <div className="card-title">⚙️ Configuración</div>
          <div className="input-group">
            <label>Nombre del destinatario</label>
            <input className="input" value={name} onChange={e=>setName(e.target.value)}/>
          </div>
          <div className="input-group">
            <label>Segmento</label>
            <select className="select" value={segment} onChange={e=>setSegment(e.target.value)}>
              <option>Hot</option><option>Warm</option><option>Cold</option>
            </select>
          </div>
          <div className="input-group">
            <label>Tu producto / servicio</label>
            <input className="input" value={context} onChange={e=>setContext(e.target.value)}/>
          </div>
          <div className="input-group">
            <label>Tono</label>
            <select className="select" value={tone} onChange={e=>setTone(e.target.value)}>
              <option>Profesional pero cercano</option>
              <option>Informal y directo</option>
              <option>Formal y corporativo</option>
              <option>Amigable y conversacional</option>
            </select>
          </div>
          <button className="btn btn-primary" style={{width:"100%"}} onClick={generate} disabled={loading}>
            {loading ? "⏳ Generando..." : "✨ Generar Email con IA"}
          </button>
        </div>

        <div className="card">
          <div className="card-title">📧 Email generado</div>
          {subject && (
            <div style={{marginBottom:12}}>
              <div className="subject-label">Asunto</div>
              <div className="subject-box">{subject}</div>
            </div>
          )}
          <div className={`ai-result ${loading && !result ? "loading" : ""}`}>
            {loading && !result ? "⏳ Generando email personalizado..." : result || "El email aparecerá aquí..."}
            {streaming && <span className="ai-cursor"/>}
          </div>
          {score !== null && <SpamScoreRing score={score}/>}
          {result && !streaming && (
            <div className="btn-row">
              <button className="btn btn-outline btn-sm" onClick={() => navigator.clipboard.writeText(result)}>📋 Copiar</button>
              <button className="btn btn-ghost btn-sm" onClick={generate}>🔄 Regenerar</button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function SpamChecker() {
  const [text,     setText]     = useState("");
  const [score,    setScore]    = useState(null);
  const [found,    setFound]    = useState([]);
  const [aiTips,   setAiTips]   = useState("");
  const [aiLoading,setAiLoading]= useState(false);

  const check = () => {
    setScore(calcSpamScore(text));
    setFound(FORBIDDEN.filter(w => text.toLowerCase().includes(w)));
  };

  const getAiTips = async () => {
    if (!text) return;
    setAiLoading(true); setAiTips("");
    try {
      const tips = await callClaude(
        `Analiza este email y dame 3 sugerencias concretas y breves para mejorar su entregabilidad. En español, numeradas, sin markdown:\n\n${text}`,
        500
      );
      setAiTips(tips);
    } catch { setAiTips("Error al conectar."); }
    setAiLoading(false);
  };

  return (
    <div>
      <div className="page-header">
        <h1>Filtro Anti-Spam</h1>
        <p>Analiza tu email antes de enviarlo</p>
      </div>
      <div className="grid-2">
        <div className="card">
          <div className="card-title">📝 Tu email</div>
          <textarea className="textarea" style={{minHeight:200}}
            placeholder="Pega aquí el asunto y cuerpo de tu email..."
            value={text} onChange={e => setText(e.target.value)}/>
          <div className="btn-row">
            <button className="btn btn-primary" onClick={check}>🔍 Analizar</button>
            <button className="btn btn-outline" onClick={getAiTips} disabled={aiLoading}>
              {aiLoading ? "⏳ Analizando..." : "🤖 Tips con IA"}
            </button>
          </div>
        </div>

        <div className="card">
          <div className="card-title">📊 Resultado</div>
          {score !== null ? (
            <>
              <SpamScoreRing score={score}/>
              <div style={{marginBottom:12}}>
                <div style={{fontSize:11,color:"var(--muted)",fontWeight:700,textTransform:"uppercase",letterSpacing:1,marginBottom:8}}>
                  Palabras detectadas
                </div>
                {found.length === 0
                  ? <span className="spam-tag ok">✅ Sin palabras prohibidas</span>
                  : found.map(w => <span key={w} className="spam-tag bad">⚠️ {w}</span>)
                }
              </div>
              <div>
                {FORBIDDEN.map(w => (
                  <span key={w} className={`spam-tag ${text.toLowerCase().includes(w) ? "bad" : "ok"}`}>
                    {text.toLowerCase().includes(w) ? "❌" : "✅"} {w}
                  </span>
                ))}
              </div>
            </>
          ) : <div style={{color:"var(--muted)",fontSize:13}}>Escribe un email y pulsa Analizar</div>}

          {aiTips && (
            <div className="ai-tips-box">
              <div className="ai-tips-title">🤖 Sugerencias IA</div>
              <div className="ai-tips-body">{aiTips}</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function Contacts() {
  const [contacts, setContacts] = useState(CONTACTS_INIT);
  const [search,   setSearch]   = useState("");
  const [filter,   setFilter]   = useState("Todos");
  const [adding,   setAdding]   = useState(false);
  const [newC,     setNewC]     = useState({name:"",email:"",segment:"Warm"});

  const filtered = contacts.filter(c => {
    const matchSearch = c.name.toLowerCase().includes(search.toLowerCase()) || c.email.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === "Todos" || c.segment === filter || c.status === filter;
    return matchSearch && matchFilter;
  });

  const add = () => {
    if (!newC.name || !newC.email) return;
    setContacts([...contacts, {...newC, id:Date.now(), opens:0, clicks:0, status:"Activo"}]);
    setNewC({name:"",email:"",segment:"Warm"});
    setAdding(false);
  };

  const segBadge    = s => s==="Hot"?"badge-red":s==="Warm"?"badge-yellow":"badge-muted";
  const statusBadge = s => s==="Activo"?"badge-green":s==="Baja"?"badge-red":"badge-muted";

  return (
    <div>
      <div className="page-header">
        <div className="page-header-row">
          <div>
            <h1>Gestión de Contactos</h1>
            <p>{contacts.length} contactos en tu lista</p>
          </div>
          <button className="btn btn-primary btn-sm" onClick={() => setAdding(!adding)}>
            {adding ? "✕ Cancelar" : "+ Añadir contacto"}
          </button>
        </div>
      </div>

      {adding && (
        <div className="card mb-4" style={{marginBottom:20}}>
          <div className="card-title">➕ Nuevo contacto</div>
          <div className="grid-3">
            <div className="input-group" style={{marginBottom:0}}>
              <label>Nombre</label>
              <input className="input" value={newC.name} onChange={e=>setNewC({...newC,name:e.target.value})} placeholder="Juan Pérez"/>
            </div>
            <div className="input-group" style={{marginBottom:0}}>
              <label>Email</label>
              <input className="input" value={newC.email} onChange={e=>setNewC({...newC,email:e.target.value})} placeholder="juan@empresa.com"/>
            </div>
            <div className="input-group" style={{marginBottom:0}}>
              <label>Segmento</label>
              <select className="select" value={newC.segment} onChange={e=>setNewC({...newC,segment:e.target.value})}>
                <option>Hot</option><option>Warm</option><option>Cold</option>
              </select>
            </div>
          </div>
          <button className="btn btn-green btn-sm" style={{marginTop:12}} onClick={add}>Guardar</button>
        </div>
      )}

      <div className="card">
        <div className="table-search">
          <input className="input" style={{flex:1}} placeholder="🔍 Buscar por nombre o email..." value={search} onChange={e=>setSearch(e.target.value)}/>
          {["Todos","Hot","Warm","Cold","Baja"].map(f => (
            <button key={f} className={`btn btn-sm ${filter===f?"btn-primary":"btn-outline"}`} onClick={() => setFilter(f)}>{f}</button>
          ))}
        </div>
        <table>
          <thead>
            <tr><th>Nombre</th><th>Email</th><th>Segmento</th><th>Aperturas</th><th>Clics</th><th>Estado</th><th></th></tr>
          </thead>
          <tbody>
            {filtered.map(c => (
              <tr key={c.id}>
                <td style={{fontWeight:600}}>{c.name}</td>
                <td style={{color:"var(--muted)",fontFamily:"var(--font-mono)",fontSize:12}}>{c.email}</td>
                <td><span className={`badge ${segBadge(c.segment)}`}>{c.segment}</span></td>
                <td style={{fontFamily:"var(--font-mono)"}}>{c.opens}</td>
                <td style={{fontFamily:"var(--font-mono)"}}>{c.clicks}</td>
                <td><span className={`badge ${statusBadge(c.status)}`}>{c.status}</span></td>
                <td><button className="btn btn-sm btn-danger" onClick={() => setContacts(contacts.filter(x => x.id!==c.id))}>✕</button></td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && <div className="empty-row">Sin resultados</div>}
      </div>
    </div>
  );
}

function AntiSpamGuide() {
  return (
    <div>
      <div className="page-header">
        <h1>Técnicas Anti-Spam 2025</h1>
        <p>Las últimas estrategias para maximizar la entregabilidad</p>
      </div>
      <div className="grid-2">
        {ANTI_SPAM_TIPS.map((t,i) => (
          <div key={i} className="tip-card">
            <div className="tip-header">
              <span className="tip-badge">{t.cat}</span>
              <span className="tip-title">{t.title}</span>
            </div>
            <div className="tip-body">{t.body}</div>
          </div>
        ))}
      </div>
      <div className="card">
        <div className="card-title">🔧 Configuración DNS recomendada</div>
        {[
          { type:"SPF",   record:'v=spf1 include:resend.com ~all' },
          { type:"DKIM",  record:'resend._domainkey → CNAME → resend.domainkey.com' },
          { type:"DMARC", record:'v=DMARC1; p=quarantine; rua=mailto:dmarc@tudominio.com' },
          { type:"MX",    record:'Apunta a tu proveedor de recepción (no mezcles con envío)' },
        ].map(r => (
          <div key={r.type} className="dns-row">
            <span className="dns-type">{r.type}</span>
            <span className="dns-record">{r.record}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function Settings({ day, setDay }) {
  const [toggles, setToggles] = useState({
    warming:true, spamFilter:true, unsubBtn:true, plainText:true, verifyLinks:true
  });
  const toggle = k => setToggles(t => ({...t, [k]:!t[k]}));

  return (
    <div>
      <div className="page-header">
        <h1>Configuración</h1>
        <p>Ajusta los parámetros de envío y warming</p>
      </div>
      <div className="grid-2">
        <div className="card">
          <div className="card-title">📬 Proveedor de envío</div>
          <div className="input-group">
            <label>Servicio</label>
            <select className="select"><option>Resend</option><option>SendGrid</option><option>Mailgun</option><option>AWS SES</option></select>
          </div>
          <div className="input-group"><label>Dominio verificado</label><input className="input" placeholder="tudominio.com"/></div>
          <div className="input-group"><label>Nombre del remitente</label><input className="input" placeholder="Tu Nombre o Empresa"/></div>
          <div className="input-group"><label>Email del remitente</label><input className="input" placeholder="hola@tudominio.com"/></div>
          <button className="btn btn-primary">💾 Guardar</button>
        </div>

        <div className="card">
          <div className="card-title">🔥 Control de Warming</div>
          <div className="input-group">
            <label>Día actual: {day} — Límite: {50+(day-1)*25} emails</label>
            <input type="range" min={1} max={20} value={day} onChange={e=>setDay(Number(e.target.value))}
              style={{width:"100%",accentColor:"var(--accent)",marginTop:6}}/>
          </div>
          <div className="input-group"><label>Pausa entre envíos (seg)</label><input className="input" type="number" defaultValue={5}/></div>

          <div className="card-title" style={{marginTop:16}}>⚙️ Funciones activas</div>
          {[
            {k:"warming",     label:"Warming automático"},
            {k:"spamFilter",  label:"Filtro anti-spam"},
            {k:"unsubBtn",    label:"Botón de baja"},
            {k:"plainText",   label:"Plain-text alternativo"},
            {k:"verifyLinks", label:"Verificar links antes de enviar"},
          ].map(item => (
            <div key={item.k} className="toggle-wrap">
              <label className="toggle">
                <input type="checkbox" checked={toggles[item.k]} onChange={() => toggle(item.k)}/>
                <span className="toggle-slider"></span>
              </label>
              <span className="toggle-label">{item.label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── EXCEL IMPORTER ──────────────────────────────────────────
function ExcelImporter() {
  const [step,       setStep]       = useState(1); // 1=upload 2=map 3=preview 4=done
  const [dragOver,   setDragOver]   = useState(false);
  const [fileName,   setFileName]   = useState("");
  const [headers,    setHeaders]    = useState([]);
  const [rows,       setRows]       = useState([]);
  const [mapping,    setMapping]    = useState({ email:"", name:"", segment:"" });
  const [imported,   setImported]   = useState([]);
  const [errors,     setErrors]     = useState([]);
  const [importing,  setImporting]  = useState(false);
  const [progress,   setProgress]   = useState(0);

  // Load SheetJS dynamically
  const loadXLSX = () => new Promise((resolve, reject) => {
    if (window.XLSX) { resolve(window.XLSX); return; }
    const s = document.createElement("script");
    s.src = "https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js";
    s.onload = () => resolve(window.XLSX);
    s.onerror = reject;
    document.head.appendChild(s);
  });

  const parseFile = async (file) => {
    setFileName(file.name);
    const XLSX = await loadXLSX();
    const buf  = await file.arrayBuffer();
    const wb   = XLSX.read(buf, { type: "array" });
    const ws   = wb.Sheets[wb.SheetNames[0]];
    const data  = XLSX.utils.sheet_to_json(ws, { header: 1, defval: "" });
    if (!data.length) return;
    const hdrs = data[0].map(h => String(h).trim());
    const rws  = data.slice(1).filter(r => r.some(c => c !== ""));
    setHeaders(hdrs);
    setRows(rws);
    // Auto-detect common column names
    const find = (keys) => hdrs.find(h => keys.some(k => h.toLowerCase().includes(k))) || "";
    setMapping({
      email:   find(["email","correo","mail","e-mail"]),
      name:    find(["nombre","name","first","apellido"]),
      segment: find(["segmento","segment","tipo","type","category"]),
    });
    setStep(2);
  };

  const handleFile = async (file) => {
    if (!file) return;
    const ok = file.name.match(/\.(xlsx|xls|csv)$/i);
    if (!ok) { alert("Solo se aceptan archivos .xlsx, .xls o .csv"); return; }
    await parseFile(file);
  };

  const handleDrop = async (e) => {
    e.preventDefault(); setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) await handleFile(file);
  };

  const runImport = async () => {
    setImporting(true); setProgress(0);
    const emailIdx   = headers.indexOf(mapping.email);
    const nameIdx    = headers.indexOf(mapping.name);
    const segmentIdx = headers.indexOf(mapping.segment);

    const ok = []; const err = [];
    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const email = String(row[emailIdx] || "").trim();
      const name  = String(row[nameIdx]  || "").trim() || `Contacto ${i+1}`;
      const seg   = String(row[segmentIdx]|| "").trim();
      const segment = ["Hot","Warm","Cold"].includes(seg) ? seg : "Cold";
      const validEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
      if (!email || !validEmail) {
        err.push({ row: i+2, email: email||"(vacío)", reason: "Email inválido" });
      } else {
        ok.push({ id: Date.now()+i, name, email, segment, opens:0, clicks:0, status:"Activo" });
      }
      setProgress(Math.round(((i+1)/rows.length)*100));
      await new Promise(r => setTimeout(r, 8));
    }
    setImported(ok); setErrors(err);
    setImporting(false); setStep(4);
  };

  const reset = () => {
    setStep(1); setFileName(""); setHeaders([]); setRows([]);
    setMapping({email:"",name:"",segment:""}); setImported([]); setErrors([]); setProgress(0);
  };

  const stepDone = (n) => step > n;
  const stepActive = (n) => step === n;

  return (
    <div>
      <div className="page-header">
        <h1>Importar desde Excel</h1>
        <p>Sube tu lista de contactos en formato .xlsx, .xls o .csv</p>
      </div>

      {/* Step indicator */}
      <div className="step-indicator">
        {[
          {n:1, label:"Subir archivo"},
          {n:2, label:"Mapear columnas"},
          {n:3, label:"Vista previa"},
          {n:4, label:"Importado"},
        ].map((s, i, arr) => (
          <div key={s.n} style={{display:"flex",alignItems:"center",flex: i<arr.length-1?1:"unset"}}>
            <div className={`step ${stepDone(s.n)?"done":stepActive(s.n)?"active":""}`}>
              <div className="step-num">{stepDone(s.n) ? "✓" : s.n}</div>
              <div className="step-label">{s.label}</div>
            </div>
            {i < arr.length-1 && <div className={`step-line ${stepDone(s.n)?"done":""}`}></div>}
          </div>
        ))}
      </div>

      {/* STEP 1 — Upload */}
      {step === 1 && (
        <div className="card">
          <div
            className={`drop-zone ${dragOver?"drag-over":""}`}
            onDragOver={e=>{e.preventDefault();setDragOver(true)}}
            onDragLeave={()=>setDragOver(false)}
            onDrop={handleDrop}
          >
            <input type="file" accept=".xlsx,.xls,.csv"
              onChange={e => e.target.files[0] && handleFile(e.target.files[0])}/>
            <div className="drop-icon">📊</div>
            <div className="drop-title">Arrastra tu archivo aquí</div>
            <div className="drop-sub">o haz clic para seleccionar</div>
            <div className="drop-formats">
              <span className="format-tag xl">XLSX</span>
              <span className="format-tag xl">XLS</span>
              <span className="format-tag csv">CSV</span>
            </div>
          </div>

          <div style={{marginTop:20,background:"rgba(0,229,255,0.04)",border:"1px solid rgba(0,229,255,0.12)",borderRadius:10,padding:16}}>
            <div style={{fontSize:12,fontWeight:700,color:"var(--accent)",marginBottom:8}}>📋 Formato recomendado del Excel</div>
            <table style={{fontSize:11}}>
              <thead>
                <tr>
                  <th>nombre</th><th>email</th><th>segmento</th><th>empresa</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ["Ana García","ana@empresa.com","Hot","Empresa S.L."],
                  ["Carlos Ruiz","carlos@startup.io","Warm","Startup Inc"],
                  ["María López","maria@corp.es","Cold","Corp SA"],
                ].map((r,i)=>(
                  <tr key={i}>{r.map((c,j)=><td key={j} style={{fontFamily:"var(--font-mono)",fontSize:11}}>{c}</td>)}</tr>
                ))}
              </tbody>
            </table>
            <div style={{fontSize:11,color:"var(--muted)",marginTop:10}}>
              💡 El campo <strong style={{color:"var(--text)"}}>email</strong> es obligatorio. Los demás se detectan automáticamente.
            </div>
          </div>
        </div>
      )}

      {/* STEP 2 — Map columns */}
      {step === 2 && (
        <div>
          <div className="card" style={{marginBottom:20}}>
            <div className="card-title">📁 Archivo: {fileName}</div>
            <div style={{fontSize:12,color:"var(--muted)",marginBottom:16}}>
              {rows.length} filas detectadas · {headers.length} columnas
            </div>

            <div className="col-mapper">
              <div className="col-mapper-title">Mapea tus columnas</div>
              {[
                { field:"email",   label:"Email",    required:true  },
                { field:"name",    label:"Nombre",   required:false },
                { field:"segment", label:"Segmento", required:false },
              ].map(f => (
                <div key={f.field} className="col-row">
                  <div className="col-field">
                    {f.label}{f.required && <span className="required">*</span>}
                  </div>
                  <span className="col-arrow">→</span>
                  <select className="select" style={{flex:1}}
                    value={mapping[f.field]}
                    onChange={e => setMapping({...mapping, [f.field]:e.target.value})}>
                    <option value="">— No mapear —</option>
                    {headers.map(h => <option key={h} value={h}>{h}</option>)}
                  </select>
                </div>
              ))}
            </div>

            <div className="btn-row">
              <button className="btn btn-outline btn-sm" onClick={reset}>← Volver</button>
              <button className="btn btn-primary"
                disabled={!mapping.email}
                onClick={() => setStep(3)}>
                Vista previa →
              </button>
            </div>
          </div>
        </div>
      )}

      {/* STEP 3 — Preview */}
      {step === 3 && (
        <div>
          <div className="import-stats">
            {[
              { val: rows.length, label:"Total filas",   color:"var(--accent)"  },
              { val: rows.filter(r=>{ const i=headers.indexOf(mapping.email); return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(r[i]||"")); }).length, label:"Válidos", color:"var(--green)" },
              { val: rows.filter(r=>{ const i=headers.indexOf(mapping.email); return !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(r[i]||"")); }).length, label:"Con error", color:"var(--red)" },
              { val: headers.length, label:"Columnas",   color:"var(--yellow)"  },
            ].map(s => (
              <div key={s.label} className="import-stat">
                <div className="import-stat-val" style={{color:s.color}}>{s.val}</div>
                <div className="import-stat-label">{s.label}</div>
              </div>
            ))}
          </div>

          <div className="card">
            <div className="card-title">👁️ Vista previa — primeras 10 filas</div>
            <div className="preview-wrap">
              <table>
                <thead>
                  <tr>
                    <th>#</th>
                    {mapping.name    && <th>Nombre</th>}
                    <th>Email</th>
                    {mapping.segment && <th>Segmento</th>}
                    <th>Estado</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.slice(0,10).map((row,i) => {
                    const email = String(row[headers.indexOf(mapping.email)]||"").trim();
                    const name  = mapping.name    ? String(row[headers.indexOf(mapping.name)]||"").trim() : "";
                    const seg   = mapping.segment ? String(row[headers.indexOf(mapping.segment)]||"").trim() : "";
                    const valid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
                    return (
                      <tr key={i}>
                        <td style={{fontFamily:"var(--font-mono)",color:"var(--muted)"}}>{i+2}</td>
                        {mapping.name    && <td style={{fontWeight:600}}>{name||"—"}</td>}
                        <td style={{fontFamily:"var(--font-mono)",fontSize:12,color:valid?"var(--text)":"var(--red)"}}>{email||"(vacío)"}</td>
                        {mapping.segment && <td><span className={`badge ${seg==="Hot"?"badge-red":seg==="Warm"?"badge-yellow":"badge-muted"}`}>{seg||"Cold"}</span></td>}
                        <td><span className={`badge ${valid?"badge-green":"badge-red"}`}>{valid?"✓ OK":"✗ Error"}</span></td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              {rows.length > 10 && <div style={{fontSize:12,color:"var(--muted)",textAlign:"center",padding:10}}>...y {rows.length-10} filas más</div>}
            </div>

            {importing && (
              <div style={{marginTop:16}}>
                <div style={{fontSize:12,color:"var(--muted)",marginBottom:6}}>Importando... {progress}%</div>
                <div className="import-progress">
                  <div className="import-progress-bar" style={{width:`${progress}%`}}></div>
                </div>
              </div>
            )}

            <div className="btn-row">
              <button className="btn btn-outline btn-sm" onClick={()=>setStep(2)}>← Volver</button>
              <button className="btn btn-primary" onClick={runImport} disabled={importing}>
                {importing ? `⏳ Importando ${progress}%...` : `✅ Importar ${rows.length} contactos`}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* STEP 4 — Done */}
      {step === 4 && (
        <div>
          <div className="import-stats">
            {[
              { val: imported.length, label:"Importados",  color:"var(--green)"  },
              { val: errors.length,   label:"Con errores", color:"var(--red)"    },
              { val: imported.filter(c=>c.segment==="Hot").length,  label:"Hot",  color:"var(--red)"    },
              { val: imported.filter(c=>c.segment==="Warm").length, label:"Warm", color:"var(--yellow)" },
            ].map(s => (
              <div key={s.label} className="import-stat">
                <div className="import-stat-val" style={{color:s.color}}>{s.val}</div>
                <div className="import-stat-label">{s.label}</div>
              </div>
            ))}
          </div>

          <div className="card" style={{marginBottom:20}}>
            <div style={{textAlign:"center",padding:"24px 0"}}>
              <div style={{fontSize:48,marginBottom:12}}>🎉</div>
              <div style={{fontSize:20,fontWeight:800,marginBottom:6}}>
                {imported.length} contactos importados correctamente
              </div>
              <div style={{fontSize:13,color:"var(--muted)"}}>
                Listos para usar en tus campañas
              </div>
            </div>
            <div className="btn-row" style={{justifyContent:"center"}}>
              <button className="btn btn-outline" onClick={reset}>📂 Importar otro archivo</button>
            </div>
          </div>

          {errors.length > 0 && (
            <div className="card">
              <div className="card-title" style={{color:"var(--red)"}}>⚠️ {errors.length} filas con errores</div>
              <table>
                <thead><tr><th>Fila</th><th>Email</th><th>Motivo</th></tr></thead>
                <tbody>
                  {errors.map((e,i) => (
                    <tr key={i}>
                      <td style={{fontFamily:"var(--font-mono)",color:"var(--muted)"}}>{e.row}</td>
                      <td style={{fontFamily:"var(--font-mono)",color:"var(--red)"}}>{e.email}</td>
                      <td style={{color:"var(--muted)"}}>{e.reason}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── NAVIGATION ──────────────────────────────────────────────
const PAGES = [
  { id:"dashboard", label:"Dashboard",       icon:"📊" },
  { id:"compose",   label:"Redactar con IA", icon:"✨", badge:"IA" },
  { id:"spam",      label:"Filtro Anti-Spam",icon:"🛡️" },
  { id:"contacts",  label:"Contactos",       icon:"👥" },
  { id:"excel",     label:"Importar Excel",  icon:"📂", badge:"NEW" },
  { id:"guide",     label:"Técnicas 2025",   icon:"🚀" },
  { id:"settings",  label:"Configuración",   icon:"⚙️" },
];

// ─── APP ROOT ────────────────────────────────────────────────
export default function App() {
  const [page, setPage] = useState("dashboard");
  const [day,  setDay]  = useState(1);

  return (
    <>
      <style>{STYLES}</style>
      <div className="app">
        <aside className="sidebar">
          <div className="logo">
            AI<span>Emailer</span>
            <small>powered by Claude</small>
          </div>
          <nav className="nav">
            {PAGES.map(p => (
              <div key={p.id} className={`nav-item ${page===p.id?"active":""}`} onClick={() => setPage(p.id)}>
                <span className="icon">{p.icon}</span>
                {p.label}
                {p.badge && <span className="sidebar-badge">{p.badge}</span>}
              </div>
            ))}
          </nav>
          <div className="sidebar-footer">
            <div className="day-label">Día de warming</div>
            <div className="day-value">{day} / 20</div>
            <div className="day-sub">Límite: {50+(day-1)*25}/día</div>
          </div>
        </aside>

        <main className="main">
          {page==="dashboard" && <Dashboard day={day} setDay={setDay}/>}
          {page==="compose"   && <AICompose/>}
          {page==="spam"      && <SpamChecker/>}
          {page==="contacts"  && <Contacts/>}
          {page==="excel"     && <ExcelImporter/>}
          {page==="guide"     && <AntiSpamGuide/>}
          {page==="settings"  && <Settings day={day} setDay={setDay}/>}
        </main>
      </div>
    </>
  );
}
