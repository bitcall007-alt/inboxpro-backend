# 🚀 AI Emailer — powered by Claude

Aplicación web completa para envío de emails con IA, warming automático y filtro anti-spam.

---

## ⚡ Instalación en 3 pasos

### 1. Instala Node.js
👉 Ve a https://nodejs.org y descarga la versión **LTS**

### 2. Abre la terminal en esta carpeta y ejecuta:
```bash
npm install
```

### 3. Pon tu API Key de Anthropic
- Ve a https://console.anthropic.com → API Keys → crea una clave
- Abre el archivo `src/App.jsx`
- Busca esta línea (está arriba del todo):
  ```js
  const ANTHROPIC_API_KEY = "sk-ant-PON-TU-CLAVE-AQUI";
  ```
- Reemplaza `sk-ant-PON-TU-CLAVE-AQUI` con tu clave real

---

## ▶️ Arrancar la app

```bash
npm run dev
```

Luego abre tu navegador en: **http://localhost:5173**

---

## 🌐 Publicar en internet (gratis con Netlify)

```bash
npm run build
```

1. Ve a https://netlify.com → crea cuenta gratis
2. Arrastra la carpeta `dist` que se genera → a la web de Netlify
3. ¡Listo! Te da un enlace público

---

## 🗂️ Estructura del proyecto

```
ai-emailer/
├── src/
│   ├── App.jsx       ← Toda la app (edita aquí tu API key)
│   └── main.jsx      ← Punto de entrada
├── index.html
├── package.json
├── vite.config.js
└── README.md         ← Este archivo
```

---

## 🔧 Funciones incluidas

| Función | Descripción |
|---------|-------------|
| 📊 Dashboard | Stats, barra de warming, gráfico de volumen |
| ✨ Redactar con IA | Genera emails personalizados con Claude |
| 🛡️ Filtro Anti-Spam | Analiza palabras prohibidas + score visual |
| 👥 Contactos | Lista con segmentación Hot/Warm/Cold |
| 🚀 Técnicas 2025 | Guía anti-spam y configuración DNS |
| ⚙️ Configuración | Proveedor, warming manual, toggles |

---

## ⚠️ Nota importante sobre la API Key

La API key está en el frontend solo para **pruebas locales**.
Cuando publiques la app en producción, debes moverla a un **servidor backend** para que no sea visible públicamente.

Una opción sencilla es usar **Netlify Functions** o **Vercel Functions** como proxy.
